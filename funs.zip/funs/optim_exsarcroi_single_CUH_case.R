#! /usr/bin/Rscript --vanilla
while( dev.next()>1 ){ dev.off() }
rm(list=ls(pos=.GlobalEnv), pos=.GlobalEnv)
if(Sys.info()[4]=="hypatia.ucc.ie"){
	setwd("/Users/eric/research/regularisation_model/opt2015")
} else {
	setwd("/Volumes/macdata/research/ucc/regularisation_model/opt2015")
}

# install.packages("ic.infer", repos='http://cran.us.r-project.org')
# install.packages("Matrix", repos='http://cran.us.r-project.org')
# install.packages("plot3D", repos='http://cran.us.r-project.org')
# install.packages("spatstat", repos='http://cran.us.r-project.org')

library(splines)
library(gplots)
library(ic.infer)
library(Matrix)
library(plot3D)
# library(spatstat)
library(Rcpp)
library(inline)
library(RcppArmadillo)
dyn.load("./Cpack/libdlam.so")
dyn.load("./Cpack/libmaths.so")
options(CBoundsCheck = TRUE)

source("utils/impro.R")
source("utils/amide.R")
source("utils/tictoc.r")
source("funs/tubemod-funs.R")
source("funs/LM_optim.R")
source("funs/C_dlam.R")
source("funs/C_maths.R")
source("funs/exsarcroi.R")
source("funs/foos.R")
# source("funs/crits_nls.R")
source("funs/plot_phases.R")
source("funs/regul_foos.R")
source("funs/Rcpp_mat.R")
sourceCpp("Cpack/grad_Rcpp.cpp")

# ------------------------------------------------------------------------ inits...
print(Sys.time())
dosynthetic=FALSE

MUTE.G = FALSE
pcut=.25
alpha=xalpha=5
nb=Jh=26 
nres=Jphi=25 
dohull=FALSE

ptid = "CUH_pt246"

gam0 = 1
modcon = list(astep=TRUE,axs=2,bxs=2,dorep=0,
			gammet = 1, gamval = gam0, lm.method = 2,
			pe.min = 1, # minimum percent error to be achieved
			maxit = 10, nbloops.b = 1, nbloops.tau = 1)
# read in the data
dirroot = paste("./data/",ptid,"/output_extractroi",sep="")

xr = matrix(
	scan(file=paste("/Volumes/macdata/research/ucc/cuh/lung/data/Lung_tsv/pt246/tumor.tsv",sep=""),
		skip=8),nc=5,byrow=TRUE)
if(0){ #### run extractroi() - run once
	if(!file.exists(dirroot)){dir.create(dirroot)}; setwd(dirroot)
	eroi = extract.roi(xr,pcut=pcut,alpha=xalpha,nb,nres)
	setwd("/Volumes/macdata/research/ucc/regularisation_model/opt2015")
	save(eroi,file=paste(dirroot,"/eroi_init.Rdata",sep=""))
}

# read in initialization output
load(file=paste(dirroot,"/eroi_init.Rdata",sep=""))
thres = scan(paste(dirroot,"/thres.txt",sep=""))
nb = Jh = eroi$Jh
nres = Jphi = eroi$Jphi
xp = matrix(scan(file=paste(dirroot,"/ROIN.txt",sep="")),nc=5,byrow=TRUE)
# read in larger VOI and adjust for mu's (as done for xp)
xt = matrix(scan(file=paste(dirroot,"/ROIT.txt",sep="")),nc=5,byrow=TRUE)
xt = xt[,c(1,3:5,2)]
ab = hab(xt)
zb = eroi$z.pasbins
for(k in 1:nb){
	ii = ((xt[,4]<=zb[k+1])&(xt[,4]>zb[k]))
	xt[ii,2] = xt[ii,2]-as.numeric(eroi$mu1[k])
	xt[ii,3] = xt[ii,3]-as.numeric(eroi$mu2[k])
}
if(1){ ### run once
	print("running spline.Omega()...")		
	Omega = spline.omega(ab)
	print("done.")		
	save(Omega,file=paste(dirroot,"/splineOmega.Rdata",sep=""))
}
# load(file=paste(dirroot,"/splineOmega.Rdata",sep=""))
