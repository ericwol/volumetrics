# Module designed to split computations between R and C code (May 2014).


# ........................................ C-wrappers ........................................

which.C <- function(a,value){
# In: C_dlam
# Calls which(double *a, int *b, int *na, int *nb, double *value)
	na = length(a)
	nb = na
	b = 0*a
	out <- .C("c_which",a=as.double(a),b=as.integer(b),	
		na=as.integer(na),nb=as.integer(nb),value=as.double(value))
	if(out$nb>0){
		return(out$b[1:out$nb])
	} else {
		return(integer(0))
	}
}

# # a = c(c(1:5),3)
# value = 3
# which(a==3)
# which(a==7)
# which.C(a,3)
# which.C(a,7)

# ........................................ R functions ........................................

ijk.lkup.tab <- function(xt,gxh,gyh,gzh){
# In: C_dlam
# Generates a lookup table for xt...
# To be passed onto C-coded function eval.dlam.C
	tab = matrix(0,nc=3,nr=nrow(xt))
	for(i in 1:nrow(xt)){
		tab[i,] = lookup.ijk(xt[i,],gxh,gyh,gzh)
	}
	return(tab)
}

xyz.lkup.tab <- function(ijk.tab,xth,gxh,gyh,gzh){
# In: C_dlam
# Generates a lookup table for ijk...
# To be passed onto C-coded function eval.dlam.C
	tab = matrix(0,nc=1,nr=nrow(xt))
	for(i in 1:nrow(ijk.tab)){
		ijk = ijk.tab[i,]
		tab[i] = lookup.xyz(ijk,xth,gxh,gyh,gzh)[1]
	}
	return(tab)
}

eval.dlam.modif <- function(xyz.tab,
							xyz.v1p.tab,xyz.v1n.tab,
							xyz.v2p.tab,xyz.v2n.tab,
							xyz.v3p.tab,xyz.v3n.tab,
							LX){
# In: C_dlam
# Evaluates discrete laplacian of lambda at all points in xx;
# xh is the augmented VOI used for computation of finite differences.
# NB: the pmax(0,LX[...]) is used to trick possible numeric(0) values
# which may arise if the point is not found in LX (this can be the 
# case e.g. when voxels inside the volume are missing).
	nx = nrow(xyz.tab)
	dval = numeric(nx)
	z0 = 0
	vrai = TRUE
	for(i in 1:length(xyz.tab)){
		v   = LX[xyz.tab[i]]
		v1p = max(z0,LX[xyz.v1p.tab[i]],na.rm=vrai)
		v1n = max(z0,LX[xyz.v1n.tab[i]],na.rm=vrai)
		v2p = max(z0,LX[xyz.v2p.tab[i]],na.rm=vrai)
		v2n = max(z0,LX[xyz.v2n.tab[i]],na.rm=vrai)
		v3p = max(z0,LX[xyz.v3p.tab[i]],na.rm=vrai)
		v3n = max(z0,LX[xyz.v3n.tab[i]],na.rm=vrai)
		dval[i] = - 6*v + v1p+v1n+v2p+v2n+v3p+v3n
	}
	return(dval)
}

dlam.wrap <- function(xx,xxh,gxh,gyh,gzh,LXH){
# In: C_dlam
	ijk.tab = ijk.lkup.tab(xx,gxh,gyh,gzh)
	# new code:
	xyz.tab = matrix(0,nc=1,nr=nrow(xx))
	xyz.v1p.tab = xyz.v1n.tab = matrix(0,nc=1,nr=nrow(xx))
	xyz.v2p.tab = xyz.v2n.tab = matrix(0,nc=1,nr=nrow(xx))
	xyz.v3p.tab = xyz.v3n.tab = matrix(0,nc=1,nr=nrow(xx))
	for(i in 1:nrow(xx)){
		ijk = ijk.tab[i,]
		xyz.tab[i] = lookup.xyz(ijk,xxh,gxh,gyh,gzh)[1]
		xyz.v1p.tab[i] = lookup.xyz(ijk+matrix(c(1,0,0),nc=3,nr=nrow(xx),byr=T),xxh,gxh,gyh,gzh)[1]
		xyz.v1n.tab[i] = lookup.xyz(ijk-matrix(c(1,0,0),nc=3,nr=nrow(xx),byr=T),xxh,gxh,gyh,gzh)[1]
		xyz.v2p.tab[i] = lookup.xyz(ijk+matrix(c(0,1,0),nc=3,nr=nrow(xx),byr=T),xxh,gxh,gyh,gzh)[1]
		xyz.v2n.tab[i] = lookup.xyz(ijk-matrix(c(0,1,0),nc=3,nr=nrow(xx),byr=T),xxh,gxh,gyh,gzh)[1]
		xyz.v3p.tab[i] = lookup.xyz(ijk+matrix(c(0,0,1),nc=3,nr=nrow(xx),byr=T),xxh,gxh,gyh,gzh)[1]
		xyz.v3n.tab[i] = lookup.xyz(ijk-matrix(c(0,0,1),nc=3,nr=nrow(xx),byr=T),xxh,gxh,gyh,gzh)[1]
	}
	#
	res =  eval.dlam.modif(xyz.tab,xyz.v1p.tab,xyz.v1n.tab,
						xyz.v2p.tab,xyz.v2n.tab,
						xyz.v3p.tab,xyz.v3n.tab,
						LXH)					
	return(res)
}

# ---------------------------------------------------------------------------------------------------------

dlam.C <- function(xyz.tab, xyz.v1p.tab,xyz.v1n.tab,
							xyz.v2p.tab,xyz.v2n.tab,
							xyz.v3p.tab,xyz.v3n.tab,
							LX){
# In: C_dlam
# Evaluates discrete laplacian of lambda at all points in xx;
# xh is the augmented VOI used for computation of finite differences.
# NB: the pmax(0,LX[...]) is used to trick possible numeric(0) values
# which may arise if the point is not found in LX (this can be the 
# case e.g. when voxels inside the volume are missing).
	nx = nrow(xyz.tab)
	dval = numeric(nx)
	out <- .C("c_dlam_old",xyztab=as.integer(xyz.tab),
						v1ptab=as.integer(xyz.v1p.tab),
						v1ntab=as.integer(xyz.v1n.tab),
						v2ptab=as.integer(xyz.v2p.tab),
						v2ntab=as.integer(xyz.v2n.tab),
						v3ptab=as.integer(xyz.v3p.tab),
						v3ntab=as.integer(xyz.v3n.tab),
						LX=as.double(LX),
						n=as.integer(nx),
						dval=as.double(dval))
	return(out$dval)
}

eval.phase.C <- function(rphs,x1s,x2s,tau,b){
# In: C_dlam
#
	vals = numeric(nrow(rphs))
	out <- .C("c_phase", rs = as.double(rphs[,1]), n = as.integer(nrow(rphs)),
				x1s = as.double(c(x1s)), n1s = as.integer(ncol(x1s)), 
				x2s = as.double(c(x2s)), n2s = as.integer(ncol(x2s)), 
				tau = as.double(tau), b = as.double(b),
				vals = as.double(vals))
	return(out$vals)
}

eval.g.C <- function(rphs,x1s,x2s,tau,b,alpha){
# In: C_dlam
#
	vals = numeric(nrow(rphs))
	out <- .C("c_g", rs = as.double(rphs[,1]), n = as.integer(nrow(rphs)),
				x1s = as.double(c(x1s)), n1s = as.integer(ncol(x1s)), 
				x2s = as.double(c(x2s)), n2s = as.integer(ncol(x2s)), 
				tau = as.double(tau), b = as.double(b),
				alpha = as.integer(alpha), vals = as.double(vals))
	return(out$vals)
}

eval.galam.C <- function(rphs,x1s,x2s,tau,a,b,alpha){
# In: C_dlam
#
	# vals = c(matrix(0,nr=n,nc=ncol(x2s)))
	vals = numeric(n*ncol(x2s))
	out <- .C("c_galam", rs = as.double(rphs[,1]), n = as.integer(nrow(rphs)),
				x1s = as.double(c(x1s)), n1s = as.integer(ncol(x1s)), 
				x2s = as.double(c(x2s)), n2s = as.integer(ncol(x2s)), 
				tau = as.double(tau), b = as.double(b),
				alpha = as.integer(alpha), vals = as.double(vals))
	return(matrix(out$vals,nr=n))
}
eval.gblam.C <- function(rphs,x1s,x2s,tau,a,b,alpha){
# In: C_dlam
#
	# vals = c(matrix(0,nr=n,nc=ncol(x2s)))
	vals = numeric((n*ncol(x2s)))
	out <- .C("c_gblam", rs = as.double(rphs[,1]), n = as.integer(nrow(rphs)),
				x1s = as.double(c(x1s)), n1s = as.integer(ncol(x1s)), 
				x2s = as.double(c(x2s)), n2s = as.integer(ncol(x2s)), 
				tau = as.double(tau), a = as.double(a), b = as.double(b),
				alpha = as.integer(alpha), vals = as.double(vals))
	return(matrix(out$vals,nr=n))
}
eval.gtlam.C <- function(rphs,x1s,x2s,tau,a,b,alpha){
# In: C_dlam
#
	# vals = c(matrix(0,nr=n,nc=ncol(x1s)))
	vals = numeric((n*ncol(x1s)))
	out <- .C("c_gtlam", rs = as.double(rphs[,1]), n = as.integer(nrow(rphs)),
				x1s = as.double(c(x1s)), n1s = as.integer(ncol(x1s)), 
				x2s = as.double(c(x2s)), n2s = as.integer(ncol(x2s)), 
				tau = as.double(tau), a = as.double(a), b = as.double(b),
				alpha = as.integer(alpha), vals = as.double(vals))
	return(matrix(out$vals,nr=n))
}

eval.lam.C <- function(rph,tau,a,b,alpha){
# In: C_dlam
# New implementation: now incorporates body of dlam.C().
# All preliminary loops are run within C code.
#
	if((modcon$axs%in%c(1,3))|(modcon$bxs==1)){
		eval.lam.R(rph,tau,a,b,alpha)
	} else {
		rphs=rph$rphs
		x1s=rph$x1s
		x2s=rph$x2s
		vals = numeric(nrow(rphs))
		out <- .C("c_lam", rs = as.double(rphs[,1]), n = as.integer(nrow(rphs)),
					x1s = as.double(c(x1s)), n1s = as.integer(ncol(x1s)), 
					x2s = as.double(c(x2s)), n2s = as.integer(ncol(x2s)), 
					tau = as.double(tau), a = as.double(a), b = as.double(b),
					alpha = as.integer(alpha), vals = as.double(vals))
		return(out$vals)
	}
}
eval.lam.C.old <- function(rphs,x1s,x2s,tau,a,b,alpha){
# In: C_dlam
# New implementation: now incorporates body of dlam.C().
# All preliminary loops are run within C code.
#
	if((modcon$axs%in%c(1,3))|(modcon$bxs==1)){
		eval.lam.R.old(rphs,x1s,x2s,tau,a,b,alpha)
	} else {
		vals = numeric(nrow(rphs))
		out <- .C("c_lam", rs = as.double(rphs[,1]), n = as.integer(nrow(rphs)),
					x1s = as.double(c(x1s)), n1s = as.integer(ncol(x1s)), 
					x2s = as.double(c(x2s)), n2s = as.integer(ncol(x2s)), 
					tau = as.double(tau), a = as.double(a), b = as.double(b),
					alpha = as.integer(alpha), vals = as.double(vals))
		return(out$vals)
	}
}

eval.dlam.C <- function(xx,xxh,gxh,gyh,gzh,LXH,retmet=0){
# In: C_dlam
# New implementation: now incorporates body of dlam.C().
# All preliminary loops are run within C code.
#
	nx = nrow(xx)
	gx = sort(unique(xx[,2]))
	gy = sort(unique(xx[,1]))
	gz = sort(unique(xx[,3]))
	dval = 0*numeric(nx)
	ijklup = 0*numeric(3*nx)
	indlup = 0*numeric(7*nx)
	vis = 0*numeric(7*nx)
	xyzlup = 0*numeric(7*nx)
	out <- .C("c_dlam",
				x1=as.double(xx[,1]),x2=as.double(xx[,2]),x3=as.double(xx[,3]),
				n=as.integer(nx),
				x1h=as.double(xxh[,1]),x2h=as.double(xxh[,2]),x3h=as.double(xxh[,3]),
				nh=as.integer(nrow(xxh)),
				gx=as.double(gx),gy=as.double(gy),gz=as.double(gz),
				nx=as.integer(length(gx)),ny=as.integer(length(gy)),nz=as.integer(length(gz)), #14
				gxh=as.double(gxh),gyh=as.double(gyh),gzh=as.double(gzh),
				nxh=as.integer(length(gxh)),nyh=as.integer(length(gyh)),nzh=as.integer(length(gzh)), #20
				LX=as.double(LXH),dval=as.double(dval), #22
				ijklup=as.integer(ijklup),xyzlup=as.double(xyzlup),indlup=as.integer(indlup),vis=as.integer(vis))
	if(retmet>0){
		return(list(dval=out$dval,
				ijklup=matrix(out$ijklup+1,nc=3,byr=T),
				xyzlup=matrix(out$xyzlup,nc=7,byr=T),
				indlup=matrix(out$indlup,nc=7,byr=T),
				vis=matrix(out$vis+1,nc=7,byr=T)))
	} else {
		return(out$dval)
	}
}

eval.grads <- function(xx,xxh,xinds,exinds,th,ha,hb,Jh,phia,phib,Jphi,alpha) {
# In: C_dlam
# Nov 2014 version
# theta = (ce,s,xi,mu1,mu2,a,b,tau)
# if dorep is:
# 	0: no reparametrization (estimation problem of dim p)
# 	1: reparametrization of s (estimation problem of dim p-1)
# --- Uses divided difference for ce,s,xi,mu1,mu2,a,b,tau
	dorep = modcon$dorep

	inds = get.inds(Jphi,Jh)
	ce  = th[inds$c]
	xi  = th[inds$xi]
	s   = th[inds$s]
	mu1 = th[inds$mu1]
	mu2 = th[inds$mu2]
	a   = th[inds$a]
	b   = th[inds$b]
	tau = th[inds$tau]

	# original data
	gyh = sort(unique(xxh[,1]))
	gxh = sort(unique(xxh[,2]))
	gzh = sort(unique(xxh[,3]))
	dx = c(diff(gyh)[1],diff(gxh)[1],diff(gzh)[1])

	# projected data
	xt = project.voi(xx,ce,s,xi)
	xth = project.voi(xxh,ce,s,xi)
	n = nrow(xt)
	nh = nrow(xth)
		
	# # evaluate splines @ theta
	rph.out.0 = eval.x.rph(xth,th,ha,hb,Jh,phia,phib,Jphi,alpha)
	GL = DGL = matrix(0,nr=nrow(xt),nc=(length(unlist(all.inds))-length(exinds)))
	mark = 1
	
	# evaluate splines + uptake model @ ce-neighbourhoods of theta
	if(!sum(is.element(c.inds,exinds))){
		for(j in 1:length(inds$c)){
			eps=max(.001,.01*dx[j]) 
			cep=ce ; cep[j]=cep[j]+eps/2
			cen=ce ; cen[j]=cen[j]-eps/2 
			xtt = project.voi(xxh,cep,s,xi)  
			thm = th
			thm[inds$c] = cep
			rph.out = eval.x.rph(xtt,thm,ha,hb,Jh,phia,phib,Jphi,alpha)
			lx.cep = eval.lam.C(rph.out,tau,a,b,alpha)
			dlx.cep = eval.dlam.C(xx,xxh,gxh,gyh,gzh,lx.cep)
			xtt = project.voi(xxh,cen,s,xi)
			thm = th
			thm[inds$c] = cen
			rph.out = eval.x.rph(xtt,thm,ha,hb,Jh,phia,phib,Jphi,alpha)
			lx.cen = eval.lam.C(rph.out,tau,a,b,alpha)
			dlx.cen = eval.dlam.C(xx,xxh,gxh,gyh,gzh,lx.cen)
			#
	 		GL[,(mark+j-1)] = (lx.cep[xinds]-lx.cen[xinds])/eps
			DGL[,(mark+j-1)] = (dlx.cep-dlx.cen)/eps
		}
		mark = mark+length(inds$c)
	}
	# evaluate splines + uptake model @ s-neighbourhoods of theta
	if(!sum(is.element(s.inds,exinds))){
		for(j in 1:length(inds$s)){
			eps=max(.001,.01*dx[j]) 
			if(dorep==1){
				sp=sn=reparam.s(s,back=TRUE)
			} else {
				sp=sn=s
			}
			sp[j]=sp[j]+eps/2 
			sn[j]=sn[j]-eps/2
			if(dorep==1){
				sp=reparam.s(sp)
				sn=reparam.s(sn)
			} 
			xtt = project.voi(xxh,ce,sp,xi)
			thm = th
			thm[inds$s] = sp
			rph.out = eval.x.rph(xtt,thm,ha,hb,Jh,phia,phib,Jphi,alpha)
			lx.sp = eval.lam.C(rph.out,tau,a,b,alpha)
			dlx.sp = eval.dlam.C(xx,xxh,gxh,gyh,gzh,lx.sp)
	 		xtt = project.voi(xxh,ce,sn,xi)
			thm = th
			thm[inds$s] = sn
			rph.out = eval.x.rph(xtt,thm,ha,hb,Jh,phia,phib,Jphi,alpha)
			lx.sn = eval.lam.C(rph.out,tau,a,b,alpha)
			dlx.sn = eval.dlam.C(xx,xxh,gxh,gyh,gzh,lx.sn)
	 		#
	 		GL[,(mark+j-1)] = (lx.sp[xinds]-lx.sn[xinds])/eps
			DGL[,(mark+j-1)] = (dlx.sp-dlx.sn)/eps
		}
		mark = mark+length(inds$s)
	}
	# evaluate splines + uptake model @ xi-neighbourhoods of theta
	if(!sum(is.element(xi.inds,exinds))){
		for(j in 1:length(inds$xi)){
			eps=2*pi/360. 
			xip=xi ; xip[j]=xip[j]+eps/2 
			xin=xi ; xin[j]=xin[j]-eps/2 
			xtt = project.voi(xxh,ce,s,xip)
			thm = th
			thm[inds$xi] = xip
			rph.out = eval.x.rph(xtt,thm,ha,hb,Jh,phia,phib,Jphi,alpha)
			lx.xip = eval.lam.C(rph.out,tau,a,b,alpha)
			dlx.xip = eval.dlam.C(xx,xxh,gxh,gyh,gzh,lx.xip)
	 		xtt = project.voi(xxh,ce,s,xin)
			thm = th
			thm[inds$xi] = xin
			rph.out = eval.x.rph(xtt,thm,ha,hb,Jh,phia,phib,Jphi,alpha)
			lx.xin = eval.lam.C(rph.out,tau,a,b,alpha)
			dlx.xin = eval.dlam.C(xx,xxh,gxh,gyh,gzh,lx.xin)
	 		#
	 		GL[,(mark+j-1)] = (lx.xip[xinds]-lx.xin[xinds])/eps
			DGL[,(mark+j-1)] = (dlx.xip-dlx.xin)/eps
		}
		mark = mark+length(inds$xi)
	}
	# evaluate splines + uptake model @ mu1-neighbourhoods of theta
	if(!sum(is.element(mu1.inds,exinds))){
		for(j in 1:length(inds$mu1)){
			eps=.01*mean(dx)/4 
			mu1p=mu1 ; mu1p[j]=mu1p[j]+eps/2 
			mu1n=mu1 ; mu1n[j]=mu1n[j]-eps/2 
			thm = th
			thm[inds$mu1] = mu1p
			rph.out = eval.x.rph(xth,thm,ha,hb,Jh,phia,phib,Jphi,alpha)
			lx.mu1p = eval.lam.C(rph.out,tau,a,b,alpha)
			dlx.mu1p = eval.dlam.C(xx,xxh,gxh,gyh,gzh,lx.mu1p)
			thm = th
			thm[inds$mu1] = mu1n
			rph.out = eval.x.rph(xth,thm,ha,hb,Jh,phia,phib,Jphi,alpha)
			lx.mu1n = eval.lam.C(rph.out,tau,a,b,alpha)
			dlx.mu1n = eval.dlam.C(xx,xxh,gxh,gyh,gzh,lx.mu1n)
	 		#
	 		GL[,(mark+j-1)] = (lx.mu1p[xinds]-lx.mu1n[xinds])/eps
			DGL[,(mark+j-1)] = (dlx.mu1p-dlx.mu1n)/eps
		}
		mark = mark+length(inds$mu1)
	}
	# evaluate splines + uptake model @ mu2-neighbourhoods of theta
	if(!sum(is.element(mu2.inds,exinds))){
		for(j in 1:length(inds$mu2)){
			eps=.01*mean(dx)/4 
			mu2p=mu2 ; mu2p[j]=mu2p[j]+eps/2 
			mu2n=mu2 ; mu2n[j]=mu2n[j]-eps/2 
			thm = th
			thm[inds$mu2] = mu2p
			rph.out = eval.x.rph(xth,thm,ha,hb,Jh,phia,phib,Jphi,alpha)
			lx.mu2p = eval.lam.C(rph.out,tau,a,b,alpha)
			dlx.mu2p = eval.dlam.C(xx,xxh,gxh,gyh,gzh,lx.mu2p)
			thm = th
			thm[inds$mu2] = mu2n
			rph.out = eval.x.rph(xth,thm,ha,hb,Jh,phia,phib,Jphi,alpha)
			lx.mu2n = eval.lam.C(rph.out,tau,a,b,alpha)
			dlx.mu2n = eval.dlam.C(xx,xxh,gxh,gyh,gzh,lx.mu2n)
			#
	 		GL[,(mark+j-1)] = (lx.mu2p[xinds]-lx.mu2n[xinds])/eps
			DGL[,(mark+j-1)] = (dlx.mu2p-dlx.mu2n)/eps
		}
		mark = mark+length(inds$mu2)
	}

	# evaluate splines + uptake model @ a-neighbourhoods of theta
	if(!sum(is.element(a.inds,exinds))){
		for(j in 1:length(inds$a)){
			eps=.01*mean(dx)/8 
			bp=bn=a
			bp[j]=bp[j]+eps/2 
			bn[j]=bn[j]-eps/2 
			thm = th
			thm[inds$a] = bp
			lx.bp = eval.lam.C(rph.out.0,tau,bp,b,alpha)
			dlx.bp = eval.dlam.C(xx,xxh,gxh,gyh,gzh,lx.bp)
	 		thm = th
			thm[inds$a] = bn
			lx.bn = eval.lam.C(rph.out.0,tau,bn,b,alpha)
			dlx.bn = eval.dlam.C(xx,xxh,gxh,gyh,gzh,lx.bn)
			#
	 		GL[,c(mark+j-1)] = (lx.bp[xinds]-lx.bn[xinds])/eps
			DGL[,c(mark+j-1)] = (dlx.bp-dlx.bn)/eps
		}	
		mark = mark+length(inds$a)
	}
	
	# evaluate splines + uptake model @ b-neighbourhoods of theta
	if(!sum(is.element(b.inds,exinds))){
		for(j in 1:length(inds$b)){
			eps=.01*mean(dx)/8 
			bp=bn=b
			bp[j]=bp[j]+eps/2 
			bn[j]=bn[j]-eps/2 
			thm = th
			thm[inds$b] = bp
			lx.bp = eval.lam.C(rph.out.0,tau,a,bp,alpha)
			dlx.bp = eval.dlam.C(xx,xxh,gxh,gyh,gzh,lx.bp)
	 		thm = th
			thm[inds$b] = bn
			lx.bn = eval.lam.C(rph.out.0,tau,a,bn,alpha)
			dlx.bn = eval.dlam.C(xx,xxh,gxh,gyh,gzh,lx.bn)
			#
	 		GL[,(mark+j-1)] = (lx.bp[xinds]-lx.bn[xinds])/eps
			DGL[,(mark+j-1)] = (dlx.bp-dlx.bn)/eps
		}	
		mark = mark+length(inds$b)
	}
	
	# evaluate splines + uptake model @ tau-neighbourhoods of theta
	if(!sum(is.element(tau.inds,exinds))){
		for(j in 1:length(inds$tau)){
			eps=.01*mean(dx)/8 
			# eps=.001*mean(tau)
			bp=bn=tau
			bp[j]=bp[j]+eps/2 
			bn[j]=bn[j]-eps/2 
			lx.bp = eval.lam.C(rph.out.0,bp,a,b,alpha)
			dlx.bp = eval.dlam.C(xx,xxh,gxh,gyh,gzh,lx.bp)
			lx.bn = eval.lam.C(rph.out.0,bn,a,b,alpha)
			dlx.bn = eval.dlam.C(xx,xxh,gxh,gyh,gzh,lx.bn)
			#
	 		GL[,(mark+j-1)] = (lx.bp[xinds]-lx.bn[xinds])/eps
			DGL[,(mark+j-1)] = (dlx.bp-dlx.bn)/eps
		}	
		mark = mark+length(inds$tau)
	}
		
	return(list(DG=GL,DGL=DGL))
}
