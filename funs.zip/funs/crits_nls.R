fnls <- function(pmu1,pmu2,ptau,th.in){
# test function...	
	th = th.in
	th[mu1.inds] = pmu1
	th[mu2.inds] = pmu2
	th[tau.inds] = ptau
	xt  = project.voi(xx,th[c.inds],th[s.inds],th[xi.inds])
	xth  = project.voi(xxh,th[c.inds],th[s.inds],th[xi.inds])
	ab = hab(xt)
	rph0 = eval.x.rph(xth,th,ab[1],ab[2],Jh,phia,phib,Jphi,alpha)
	LXHc = eval.lam.R(rph0,
					th[tau.inds],th[a.inds],th[b.inds],alpha)
	return(LXHc[xinds])
}

# -------------------------------------------------------------------------------- 
# non-regularized functions

csxm.fn <- function(pc,ps,pxi,pmu1,pmu2,th.in){
# (c,s,xi) and (mu1,mu2) optimization
	th = th.in
	th[c.inds] = pc
	th[s.inds] = ps
	th[xi.inds] = pxi
	th[mu1.inds] = pmu1
	th[mu2.inds] = pmu2
	xt  = project.voi(xx,th[c.inds],th[s.inds],th[xi.inds])
	xth  = project.voi(xxh,th[c.inds],th[s.inds],th[xi.inds])
	ab = hab(xt)
	rphc = eval.x.rph(xth,th,ab[1],ab[2],Jh,phia,phib,Jphi,alpha)
	LXHc = eval.lam.R(rphc,th[tau.inds],th[a.inds],th[b.inds],alpha)
	return(LXHc[xinds])	
}

tau.fn <- function(ptau,th.in,rphc){
# tau-only optimization, non-regularized	
	th = th.in
	th[tau.inds] = ptau
	LXHc = eval.lam.R(rphc,th[tau.inds],th[a.inds],th[b.inds],alpha)
	return(LXHc[xinds])
}

p.fn <- function(pin,pis,th.in,rphc){
# p-only optimization, non-regularized	
	th = th.in
	th[pis] = pin
	LXHc = eval.lam.R(rphc,th[tau.inds],th[a.inds],th[b.inds],alpha)
	return(LXHc[xinds])
}

# -------------------------------------------------------------------------------- 
# regularized functions (optim)

csxm.gam <- function(pc,ps,pxi,pmu1,pmu2,th.in,gam){
# (c,s,xi) and (mu1,mu2) optimization
	th = th.in
	th[c.inds] = pc
	th[s.inds] = ps
	th[xi.inds] = pxi
	th[mu1.inds] = pmu1
	th[mu2.inds] = pmu2
	xt  = project.voi(xx,th[c.inds],th[s.inds],th[xi.inds])
	xth  = project.voi(xxh,th[c.inds],th[s.inds],th[xi.inds])
	ab = hab(xt)
	rphc = eval.x.rph(xth,th,ab[1],ab[2],Jh,phia,phib,Jphi,alpha)
	LXHc = eval.lam.R(rphc,th[tau.inds],th[a.inds],th[b.inds],alpha)
	GLXHc = eval.dlam.C(xx,xxh,gxh,gyh,gzh,LXHc)
	return(sum((z-LXHc[xinds])^2 + gam*GLXHc^2))
}	

p.gam <- function(p,is,th.in,rphc,gam){
# e.g. tau-, a- or b-only optimization
	th = th.in
	th[is] = p
	LXHc = eval.lam.R(rphc,th[tau.inds],th[a.inds],th[b.inds],alpha)
	GLXHc = eval.dlam.C(xx,xxh,gxh,gyh,gzh,LXHc)
	return(sum((z-LXHc[xinds])^2 + gam*GLXHc^2))
}

tau.gam <- function(ptau,th.in,rphc,gam){
# tau-only optimization
	return(p.gam(ptau,tau.inds,th.in,rphc,gam))
}

mcrit <- function(th,gam=0){
# In: crit_nls.R
	ab = hab(xt)
	LXHc = eval.lam.C(orph,th[tau.inds],th[a.inds],th[b.inds],alpha)
	# GLXHc = eval.dlam.C(xx,xxh,gxh,gyh,gzh,LXHc)
	# if(gam){
		# return(sum((z-LXHc[xinds])^2 + gam*GLXHc^2))
	# } else {
		return(sum((z-LXHc)^2))
	# }
}
