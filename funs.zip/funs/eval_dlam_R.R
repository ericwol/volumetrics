eval.dlam.R <- function(xx,lx){
# In: LM_optim
# Evaluates spatial Laplacian of lx at all points in VOI xx.
# xx can be any shape, not just a raster.
	gx = sort(unique(xx[,2]))
	gy = sort(unique(xx[,1]))
	gz = sort(unique(xx[,3]))
	n = nrow(xx)
	dvals = numeric(n)
	dx = unique(abs(diff(gx)))[1]
	dy = unique(abs(diff(gy)))[1]
	dz = unique(abs(diff(gz)))[1]
	for(i in 1:n){
		xyz = xx[i,]
		ix = which((xx[,1]==xyz[1])&(xx[,3]==xyz[3]))
		sx = matrix(xx[ix,],nc=3)
		iy = which((xx[,2]==xyz[2])&(xx[,3]==xyz[3]))
		sy = matrix(xx[iy,],nc=3)
		iz = which((xx[,1]==xyz[1])&(xx[,2]==xyz[2]))
		sz = matrix(xx[iz,],nc=3)
		# v1 = ix[which(sx[,1]==xyz[1]+dx)], etc.
		# alternatively, and also deals with ocnditions at borders:
		v1 = ix[which.min(abs(sx[,2]-(xyz[2]+dx)))] 
		v2 = ix[which.min(abs(sx[,2]-(xyz[2]-dx)))] 
		v3 = iy[which.min(abs(sy[,1]-(xyz[1]+dy)))] 
		v4 = iy[which.min(abs(sy[,1]-(xyz[1]-dy)))] 
		v5 = iz[which.min(abs(sz[,3]-(xyz[3]+dz)))] 
		v6 = iz[which.min(abs(sz[,3]-(xyz[3]-dz)))] 
		dvals[i] = - 6*lx[i] + lx[v1]+lx[v2]+lx[v3]+lx[v4]+lx[v5]+lx[v6]
	}
	return(dvals)
}

