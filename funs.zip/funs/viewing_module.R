# requires: source("./S_rfuns.R")

as.real <- function(x){ as.double(x) }

comp.dd <- function(x){
	d3=max(diff(as.real(names(table(x[,3])))))
	d2=max(diff(as.real(names(table(x[,2])))))
	d1=max(diff(as.real(names(table(x[,1])))))
	dd=min(d1,d2,d3)*1.2
	return(dd)
}

comp.thres <- function(y,pcut=.25){
	n=length(y)
	yl=sort(y)[.1*n]
	ym=sort(y[y>yl])[.5*n]
	nn=min(1000,.1*n) 
	my=median(sort(y)[c((n-nn):n)])
	thres=max(.1*my,sort(y[y>yl])[pcut*n])
	return(thres)
}

comp.struct.params <- function(x,y,thres){
# x = 3D coordinate information from ROIA.txt. From this, 
# 	xt = cbind(x[,1]-mu[1],x[,2]-mu[2],x[,3]-mu[3])%*%gam
# feeds into msg()
	out.arot=arotx(x,y,thres) 
	mu=out.arot$amide[,1] 
	gam=t(out.arot$amide[,2:4]) 
	return(list(mu=mu,gam=gam,c=out.arot$c,s=out.arot$s,xi=euler.angles(out.arot$Gxi,method=0)))
}

analyze.info <- function(xx,z,nb){
	n  = length(z)
	nv = max(100,n/nb) 
	nb = round(max(1,n/nv)) 
	dd = comp.dd(xx)
	thres = comp.thres(z)
	out = comp.struct.params(xx,z,thres)
	xxt = cbind(xx[,1]-out$mu[1],xx[,2]-out$mu[2],xx[,3]-out$mu[3])%*%out$gam
	outm = msg(xxt,z,thres,alpha=5,dd,nb=26,nres=25,doplot=F)
	return(list(struct=out,out.msg=outm,xxt=xxt))
}
analyse.info <- function(xx,z,nb){
	analyze.info(xx,z,nb)
}

out.roid <- function(xt,y,oai.outm){
# wrapper; using oai.outm, output of msg() as returned by analyse.info().
	return(roid(xt,y,oai.outm$z,oai.outm$m,oai.outm$sg))
}

out.fitg <- function(o.roid,o.outm,nu=25){
# wrapper; uses output of msg() as returned by analyse.info(),
# and of roid(), as returned by out.roid().
	return(fitg(o.roid$zuy,nrow(o.outm$sg),nu))
}

plot.phase.profile <- function(x3,y,uv,eo,sg,nu=25,doplotscale=TRUE,text=""){
# Input:
#	x3 = raw z-axis info 
#	y  = raw uptake
#	uv = "new" polar information
#	eo = output of out.fitg()
#	nz = nrow(outm$sg) where outm = msg(...)
# Usage:
#	uv = eval.phase.C(RPH0[xinds,],x1s,x2s,tau,b)
# 	ai = analyze.info(xx,z,nb)
#	ai.outm = ai$out.msg
# 	o = out.roid(xt,y,ai.outm)
# 	e.out = out.fitg(o,ai.outm)
#	plot.phase.profile(xt[,3],z,uv,e.out,sg)
# ...
	z=x3
	nz = nrow(sg)
	n=length(y) 
	nv=round(max(1,n/nz)) 
	ub=sort(uv)[c(1,c(1:(nu-1))*nv,n)] 
	# building z-grid
	zb=sort(z)[c(1,c(1:(nz-1))*nv,n)] 
	zb[1]=zb[1]-max(.1e-9,.001*(zb[2]-zb[1])) 
	mhat=matrix(rep(0,(nu+1)*nz),ncol=nz) 
	for(k in 1:nz) {
		yu=y[(z<=zb[k+1])&(z>zb[k])] 
		u=uv[(z<=zb[k+1])&(z>zb[k])]
		fac=mean(yu) 
		if(abs(fac)<1e-20) {
			fac=1e-20
		}
		yu=sort(yu/fac)
		u=sort(u) 
		# now smooth across slices
		mhat[,k]=fac*approx(unismooth2(u,yu),xo=ub,rule=2)$y
	}
	#--------
	e = eo
	par(pty="m",mar=c(4,3,5,3))
	# creating imn, the color levels to be used in plot:
	imn=e$ims*0
	imn=rbind(rep(0,nz),imn)
	# used for overlay contour line:
	rad=apply(sg,1,mean) 
	nz=length(rad)
	# controlling "z-axial resolution":
	ff=(max(e$pars[,1])-min(e$pars[,1]))/max(rad)
	ff=2.
	# now evaluate levels at each slice:
	for(k in 1:nz) { 
		sfac=rad[k]/max(rad)
		uk=c(1:(nu+1))*sfac
	 	imn[,k]=approx(uk,mhat[,k],xout=c(0:(nu+1))*ff,rule=2,yright=0)$y 
	}
	# plot:
	image(c(0:(nu+1))*ff,e$pars[,1],-imn,col=grey((0:255)/256),
			ylab="z (mm)",xlab=" ",axes=F,main=paste("Phase profile",text))
	lines((nu+1)*rad/max(rad),e$pars[,1],lty=c(3))
	axis(2)
	axis(1,at=c(1,(nu)),labels=c("C","B"),cex=.2)
	if(doplotscale){
		par(mar=c(4,3,1,3))
		image.scale(-imn, range(-imn), col=grey((0:15)/16), xlab="", ylab="")	
		box()
	}
}

plot.radial.uptake <- function(e.out,sg,nu=25,doplotscale=TRUE,text=""){
# e.out = output of out.fitg()
# Usage:
# 	ai = analyze.info(xx,z,nb)
#	ai.outm = ai$out.msg
# 	o = out.roid(xt,y,ai.outm)
# 	e.out = out.fitg(o,ai.outm)
#	plot.radial.uptake(e.out,ai.outm$sg,nrow(ai.outm$sg),nu)
# ...
	nz = nrow(sg)
	e = e.out
	# creating imn, the color levels to be used in plot:
	imn=e$ims*0
	imn=rbind(rep(0,nz),imn)
	# used for overlay contour line:
	rad=apply(sg,1,mean) 
	nz=length(rad)
	# controlling "z-axial resolution":
	ff=(max(e$pars[,1])-min(e$pars[,1]))/max(rad)
	ff=2.
	# now evaluate levels at each slice:
	for(k in 1:nz) { 
		sfac=rad[k]/max(rad)
		uk=c(1:(nu+1))*sfac
	 	imn[,k]=approx(uk,e$ims[,k],xout=c(0:(nu+1))*ff,rule=2,yright=0)$y 
	}
	# plot:
	par(pty="m",mar=c(4,3,5,3))
	image(c(0:(nu+1))*ff,e$pars[,1],-imn,col=grey((0:255)/256),
			ylab="z (mm)",xlab=" ",axes=F,main=paste("Radial Uptake",text))
	lines((nu+1)*rad/max(rad),e$pars[,1],lty=c(3))
	axis(2)
	axis(1,at=c(1,(nu)),labels=c("C","B"),cex=.2)
	if(doplotscale){
		par(mar=c(4,3,1,3))
		image.scale(-imn, range(-imn), col=grey((0:15)/16), xlab="", ylab="")	
		box()
	}
}

view.voi <- function(struct,outm,rrx=1.1,strip=""){
# 3D meshing (original and PAS domains)
# Requires struct = output from analyze.info()
# Requires outm = output from msg()
	mu1t=struct$mu[1]
	mu2t=struct$mu[2]
	bxt = bpts(outm$z,outm$m,outm$th,outm$sg)
	nxt = npts(outm$z,outm$m,outm$th,outm$sg) 		# Surface and Normals - PAS domain
	bxo = cbind(bxt[,1],bxt[,2],bxt[,3])%*%t(struct$gam) 
	bxo = cbind(bxo[,1],bxo[,2],1.4*bxo[,3])  	# Surface             - Original domain
	nxo = cbind(nxt[,1],nxt[,2],nxt[,3])%*%t(struct$gam) 
	nxo = cbind(nxo[,1],nxo[,2],1.4*nxo[,3])  	# Normals             - Original domain
	# plot!	
	# Original domain
	xv=c(0,1,0)
	viewxv2(xv,bxt,bxo,nxo,"x3","x1",paste("Original",strip),rrx)
	xv=c(1,0,0)
	viewxv2(xv,bxt,bxo,nxo,"x3","x2"," ",rrx)
	xv=c(0,0,1)
	viewxv2(xv,bxt,bxo,nxo,"x2","x1"," ",rrx) 
	# PAS domain
	xv=c(0,1,0)
	viewxv(xv,cbind(bxt[,1],bxt[,2],bxt[,3]),cbind(nxt[,1],nxt[,2],nxt[,3]),
			"x3'","x1'",paste("Transformed (PAS)",strip),rrx) 
	xv=c(1,0,0)
	viewxv(xv,cbind(bxt[,1],bxt[,2],bxt[,3]),cbind(nxt[,1],nxt[,2],nxt[,3]),
			"x3'","x2'"," ",rrx)
	xv=c(0,0,1)
	viewxv(xv,cbind(bxt[,1],bxt[,2],bxt[,3]),cbind(nxt[,1],nxt[,2],nxt[,3]),
			"x2'","x1'"," ",rrx)
	invisible(list(bxt=bxt,bxo=bxo,nxo=nxo,nxt=nxt))
}

image.scale <- function(z, zlim, col = heat.colors(12),
			breaks, horiz=TRUE, ylim=NULL, xlim=NULL, ...){
# Source: http://menugget.blogspot.ie/2011/08/adding-scale-to-image-plot.html#more
# This function creates a color scale for use with e.g. the image()
# function. Input parameters should be consistent with those
# used in the corresponding image plot. The "horiz" argument
# defines whether the scale is horizonal(=TRUE) or vertical(=FALSE).
# Depending on the orientation, x- or y-limits may be defined that
# are different from the z-limits and will reduce the range of
# colors displayed.	
 if(!missing(breaks)){
  if(length(breaks) != (length(col)+1)){stop("must have one more break than colour")}
 }
 if(missing(breaks) & !missing(zlim)){
  breaks <- seq(zlim[1], zlim[2], length.out=(length(col)+1)) 
 }
 if(missing(breaks) & missing(zlim)){
  zlim <- range(z, na.rm=TRUE)
  zlim[2] <- zlim[2]+c(zlim[2]-zlim[1])*(1E-3)#adds a bit to the range in both directions
  zlim[1] <- zlim[1]-c(zlim[2]-zlim[1])*(1E-3)
  breaks <- seq(zlim[1], zlim[2], length.out=(length(col)+1))
 }
 poly <- vector(mode="list", length(col))
 for(i in seq(poly)){
  poly[[i]] <- c(breaks[i], breaks[i+1], breaks[i+1], breaks[i])
 }
 xaxt <- ifelse(horiz, "s", "n")
 yaxt <- ifelse(horiz, "n", "s")
 if(horiz){YLIM<-c(0,1); XLIM<-range(breaks)}
 if(!horiz){YLIM<-range(breaks); XLIM<-c(0,1)}
 if(missing(xlim)) xlim=XLIM
 if(missing(ylim)) ylim=YLIM
 plot(1,1,t="n",ylim=ylim, xlim=xlim, xaxt=xaxt, yaxt=yaxt, xaxs="i", yaxs="i", ...)  
 for(i in seq(poly)){
  if(horiz){
   polygon(poly[[i]], c(0,0,1,1), col=col[i], border=NA)
  }
  if(!horiz){
   polygon(c(0,0,1,1), poly[[i]], col=col[i], border=NA)
  }
 }
}
