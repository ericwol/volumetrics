### -----------------------------------------------------------------------------
compute.gradients <- function(u, yh, do.up=FALSE){
# u = phases
# yh = profile curve (smooth model curve)	
	ip = order(u)
	u = u[ip]
	yh = yh[ip]
	if(do.up){
		u = u/median(ifelse(u>.001,u,.001))
		uu = unismooth(u,y)
		yh = uu[,2]
	}
	grp = (approx(u,yh,xout=u*1.1,rule=2)$y-approx(u,yh,xout=u*.9,rule=2)$y)
	grp = -grp/(ifelse(u>.01,u,.01)*.2)
	return(list(phases=u, profile=yh, indices=ip, 
				gradients=grp, 
				weighted.gradients=grp*yh, 
				normalized.gradients=grp/max(yh,na.rm=TRUE)))
}

# g.im = rasterize.voi(cbind(-grp,c(1+0*z),xx[ip,]),def=NA)
# gp.im = rasterize.voi(cbind(gp,c(1+0*z),xx[ip,]),def=NA)
# as.out = rasterize.voi(cbind(aas[ip],c(1+0*z),xx[ip,]))
# as.out = as.out/max(as.out)
# # cphg = as.out*g.im # aterm * grad_term raster
# cphg = as.out*gp.im*g.im # aterm * grad_term raster

### -----------------------------------------------------------------------------
sixF.backup <- function(out,zdim,xdim,bndT=.75,resign=TRUE,doplot=FALSE){
# Six-number summary of tumor uptake.
# Arguments:
#	out = output of hetE.an.bitonic() 
# 	zdim = slice thickness
# 	xdim = voxel transverse dimensions
# 	bndT = cutoff quantile point defining the start of the boundary rim 
# Ex: zdim=xx$Thickness[kk]; xdim=xx$InPlaneDim[kk]
# Values:
# 	fractional.void = F1
# 	volume = F2
# 	contrast.ratio = F3
# 	max = F4
# 	boundary.gradient = F5
# 	cv = F6
# 	y = model uptake (where y = out$v[order(v[,1],3])
# 	gradients = all gradient values evaluated at locations u 
# 			(expressed in the units of the input uptake values)
# 			(where u is a normalized version of sort(out$v[,1]))
# 	normalized.gradients = gradients/F4 (unitless, normalized to (-1,1))
# 	w.gradients = uptake-weighted normalized gradients,
# 	bnd.gradients = gradients at boundary
# 	normalized.bnd.gradients = normalized gradients at boundary
# 	w.bnd.gradients = uptake-weighted (normalized) gradients at boundary
# Note: in fact, sixF only uses output component hetE.an.bitonic()$v, where 
# hetE.an.bitonic()$v = hetE.bitonic()$bitonic.reg.out
# So essentially hetE.an.bitonic() is now obsolete...
# 
	vb = out$v
	o = order(vb[,1])
	y = vb[o,3]
	u = vb[o,1] 
	u = u/median(ifelse(u>.001,u,.001))
	uu = unismooth(u,y)
	yh = uu[,2]
	um = u[order(-yh)[1]]   # mode of unimodal uptake profile
	ym = min(yh) 			# uptake value at mode
	nu = length(u)
	if(doplot){
		matplot(u,cbind(y,yh),
			pch=20,cex=.8,col=c(1,2),lty=1,type="pb",xlab="u-Dist",ylab="Uptake")
	}
	maxyh = max(yh)
	A = mean(yh[u<=um])-ym 
	B = mean(yh[u>um])-ym 
	F1 = A/(A+B)									# Fractional Void (voxel weighted)
	F2 = nu*zdim*xdim*xdim							# Volume of Tumor
	F3 = 1-min(yh)/maxyh	    		   			# Contrast Ratio
	F4 = maxyh										# Max
	grad = (approx(u,yh,xout=u*1.1,rule=2)$y-approx(u,yh,xout=u*.9,rule=2)$y)/(ifelse(u>.01,u,.01)*.2)
	if(resign){grad = -grad}
	wgrad = (grad/maxyh)*y
	F5 = 0-mean(grad[u>=quantile(u,bndT)])/maxyh	# (Mean) boundary gradient
	F6 = mean( abs(y-yh) )/maxyh					# COV about the Tumor Profile
	# return(c(F1,F2,F3,F4,F5,F6))
	res = list(fractional.void=F1,volume=F2,contrast.ratio=F3,
				max=F4,boundary.gradient=F5,cv=F6,
				y=y,
				gradients=grad,
				normalized.gradients=grad/maxyh,
				w.gradients=wgrad,
				bnd.gradients=grad[u>=quantile(u,bndT)],
				normalized.bnd.gradients=grad[u>=quantile(u,bndT)]/maxyh,
				w.bnd.gradients=wgrad[u>=quantile(u,bndT)])
}
