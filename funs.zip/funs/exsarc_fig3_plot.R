# par(mfrow=c(2,2),font=2,font.lab=2,font.axis=2,pty="m")
# reproduce fig3.pdf
# (a)
nz=Jh
nu=Jphi
e=fitg(eroi$zuy,nz,nu) 
imn=e$ims*0
imn=rbind(rep(0,nz),imn)
rad=apply(eroi$sg,1,mean) 
nz=length(rad)
ff=(max(e$pars[,1])-min(e$pars[,1]))/max(rad)
ff=2.
for(k in 1:nz) { 
	sfac=rad[k]/max(rad)
	uk=c(1:(nu+1))*sfac
 	imn[,k]=approx(uk,e$ims[,k],xout=c(0:(nu+1))*ff,rule=2,yright=0)$y 
}
image(c(0:(nu+1))*ff,e$pars[,1],-imn,col=grey((0:255)/256),
		ylab="z (mm)",xlab=" ",axes=F,main="Radial Uptake (extract)")
lines((nu+1)*rad/max(rad),e$pars[,1],lty=c(3))
axis(2)
axis(1,at=c(1,(nu)),labels=c("C","B"),cex=.2)
#
# (b)
v=eroi$efit[,1]
vm=max(v)
vm=1
v=v/vm 
yn = ghat
wy=eroi$efit[,2]
wy=wy/max(wy) 
wcut=sort(wy)[.4*length(wy)]
if(wcut==max(wy)){ 
	wcut=sort(wy)[.2*length(wy)]
}
plot(v[wy>wcut],yn[wy>wcut],pch=".",main="Profile (extract)",
		axes=F,xlab="[<- Core]     Phase    [Boundary ->]",ylab="Uptake")
axis(1); axis(2)
lines(unismooth2(v[wy>wcut],yn[wy>wcut]),lwd=c(2),col=c(3))
#
# (d)
plot(100-100*e$pars[,3],e$pars[,1],xlim=c(0,100),
		main="Heterogeneity (extract)",axes=F,xlab="1-R^2",ylab="z (mm)")
axis(1); axis(2) 
#
# (c)
o=smooth.spline(e$pars[,1],e$pars[,8]/vm)
plot(e$pars[,4]/vm,e$pars[,1],pch="*",type="n",	
		main="Phase (extract)",axes=F,xlab=" ",ylab="z (mm)",
		xlim=range(v[wy>wcut],o$y))
lines(o$y,o$x,lwd=c(2),col=c(2))
o=smooth.spline(e$pars[,1],e$pars[,4]/vm)
lines(o$y,o$x,lwd=c(2))
points(e$pars[,5]/vm,e$pars[,1],pch=".",type="n",col=c(4))
points(e$pars[,6]/vm,e$pars[,1],pch=".",type="n",col=c(4))
ol=smooth.spline(e$pars[,1],e$pars[,5]/vm)
ou=smooth.spline(e$pars[,1],e$pars[,6]/vm)
lines(ol$y,ol$x,pch="=",col=c(4))
lines(ou$y,ou$x,pch="=",col=c(4))
axis(1); axis(2)
